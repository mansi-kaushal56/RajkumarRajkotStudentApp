//
//  APIRequests.swift
//  HAPSStudentApp
//
//  Created by Vijay Sharma on 21/06/23.
//

import Foundation

protocol RequestApiDelegate {
    func success(api:String, response : [String : Any])
    func failure()
}

class ApiRequest : NSObject {
    var delegate : RequestApiDelegate?
    func requestAPI(apiName : String, apiRequestURL : String) {
        guard let serviceUrl = URL(string: apiRequestURL) else { return }
        
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = "POST"
        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        guard let httpBody = try? JSONSerialization.data(withJSONObject: [:], options: []) else {
            return
        }
        request.httpBody = httpBody
        request.timeoutInterval = 20
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            if let error = error {
                if let urlError = error  as? URLError, urlError.code == .notConnectedToInternet {
                    DispatchQueue.main.async {
                        CommonObjects.shared.stopProgress()
                        CommonObjects.shared.showToast(message: AppMessages.MSG_NO_INTERNET)
                    }
//                    CommonObjects.shared.showToast(message: "Hello")
                } else if (error as NSError).code == NSURLErrorTimedOut {
                    DispatchQueue.main.async {
                        CommonObjects.shared.stopProgress()
                        CommonObjects.shared.showToast(message: AppMessages.MSG_TIME_OUT)
                    }
                }
                
            }
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                    self.delegate?.success(api: apiName, response: json as! [String : Any])
                    CommonObjects.shared.stopProgress()
                    
                } catch {
                    print(error)
                    self.delegate?.failure()
                    CommonObjects.shared.stopProgress()
                }
            }
        }.resume()
    }
    func uploadImage(imageData: Data, apiURL: String) {
        
        let request = MultipartFormDataRequest(url: (URL(string: apiURL)!))//(url: URL(string: "https://pbtechplacements.com/admin/uploads/")!)
        request.addDataField(named: "profilePicture", data: imageData, mimeType: ".jpg", dataType: false)
        
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                    //self.delegate?.success(api: apiName, response: json as! [String : Any])
                    
                } catch {
                    print(error)
                    self.delegate?.failure()
                }
            }
        }.resume()
       /*
//        URLSession.shared.dataTask(with: request, completionHandler: {_,_,_ in
//
//            print(request.self)
//
//        }).resume()
        */
    }
}
struct MultipartFormDataRequest {
    private let boundary: String = UUID().uuidString
    private var httpBody = NSMutableData()
    let url: URL
    
    init(url: URL) {
        self.url = url
    }
/*
//    func addTextField(named name: String, value: String) {
//        httpBody.append(textFormField(named: name, value: value))
//    }
//
//    private func textFormField(named name: String, value: String) -> String {
//        var fieldString = "--\(boundary)\r\n"
//        fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
//        fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
//        fieldString += "Content-Transfer-Encoding: 8bit\r\n"
//        fieldString += "Content-Disposition: form-data; name=\"file\"; filename=\"\("myImage")\"\r\n"
//
//        fieldString += "\r\n"
//        fieldString += "\(value)\r\n"
//
//        return fieldString
//    }
 */
    
    func addDataField(named name: String, data: Data, mimeType: String,dataType: Bool) {
        httpBody.append(dataFormField(named: name, data: data, mimeType: mimeType))
    }
    
    private func dataFormField(named name: String,
                               data: Data,
                               mimeType: String) -> Data {
        let fieldData = NSMutableData()
        fieldData.append("--\(boundary)\r\n".data(using: .utf8)!)
        //fieldData.append("Content-Disposition: form-data; name=\"\(name)\"\r\n")
        fieldData.append("Content-Disposition: form-data; name=\"file\"; filename=\"\("imageFile.jpg")\"\r\n".data(using: .utf8)!)
        fieldData.append("Content-Type: \(mimeType)\r\n")
        fieldData.append("\r\n")
        fieldData.append(data)
//        fieldData.append("\r\n")
        fieldData.append("\r\n".data(using: .utf8)!)
        fieldData.append("--\(boundary)--\r\n".data(using: .utf8)!)
        print(fieldData)
        return fieldData as Data
    }
    
    func asURLRequest() -> URLRequest {
        var request = URLRequest(url: url)
        
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        httpBody.append("--\(boundary)--")
        request.httpBody = httpBody as Data
        return request
    }
}
extension NSMutableData {
    func append(_ string: String) {
        if let data = string.data(using: .utf8) {
            self.append(data)
        }
    }
}
extension URLSession {
    func dataTask(with request: MultipartFormDataRequest,
                  completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void)
    -> URLSessionDataTask {
        return dataTask(with: request.asURLRequest(), completionHandler: completionHandler)
    }
}
